# Library Management System

Academic project developed in Java for an Object-Oriented Programming course at Instituto Superior Técnico.

The application manages library users, books and DVDs, borrowing and returns, borrowing rules, fines, notifications, inventory, search and persistent application state.

## Technologies
- Java
- Object-Oriented Programming
- Serialization / persistence
- Observer pattern

> Note: the user-interface layer depends on the `pt.tecnico.uilib` library provided in the course environment.
