
package bci.app.main;

import bci.app.exception.FileOpenFailedException;
import bci.core.LibraryManager;
import bci.core.exception.MissingFileAssociationException;
import bci.core.exception.UnavailableFileException;
import java.io.IOException;
import pt.tecnico.uilib.forms.Form;
import pt.tecnico.uilib.menus.Command;
import pt.tecnico.uilib.menus.CommandException;

class DoOpenFile extends Command<LibraryManager> {

   DoOpenFile(LibraryManager receiver) {
     super(Label.OPEN_FILE, receiver);
   }

@Override
protected final void execute() throws CommandException {
  if (_receiver.hasUnsavedChanges()) {
    Form saveForm = new Form();
    saveForm.addBooleanField("save", Prompt.saveBeforeExit());
    saveForm.parse();
    if (saveForm.booleanField("save")) {
      try {
        _receiver.save();
      } catch (MissingFileAssociationException e) {
        Form saveAsForm = new Form();
        saveAsForm.addStringField("saveAsName", Prompt.newSaveAs());
        saveAsForm.parse();
        String saveAsName = saveAsForm.stringField("saveAsName");
        try {
          _receiver.saveAs(saveAsName);
        } catch (MissingFileAssociationException | IOException ex) {
          throw new FileOpenFailedException(ex);
        }
      } catch (IOException e) {
        throw new FileOpenFailedException(e);
      }
    }
  }

  Form openForm = new Form();
  openForm.addStringField("filename", Prompt.openFile());
  openForm.parse();
  String filename = openForm.stringField("filename");
  try {
    _receiver.load(filename);
  } catch (UnavailableFileException e) {
    throw new FileOpenFailedException(e);
  }
}
}