package bci.app.main;

import bci.app.exception.FileOpenFailedException;
import bci.core.LibraryManager;
import bci.core.exception.MissingFileAssociationException;
import pt.tecnico.uilib.forms.Form;
import pt.tecnico.uilib.menus.Command;
import pt.tecnico.uilib.menus.CommandException;
/**
 * Save to file under current name (if unnamed, query for name).
 */
class DoSaveFile extends Command<LibraryManager> {

  DoSaveFile(LibraryManager receiver) {
    super(Label.SAVE_FILE, receiver);
  }

  @Override
  protected final void execute() throws CommandException {
    try {
      _receiver.save();
    } catch (MissingFileAssociationException e) {
      Form form = new Form();
      form.addStringField("filename", "Ficheiro sem nome. Guardar ficheiro como: ");
      form.parse();
      String filename = form.stringField("filename");
      try {
        _receiver.saveAs(filename);
      } catch (Exception ex) {
        throw new FileOpenFailedException(ex);
      }
    } catch (Exception e) {
      throw new FileOpenFailedException(e);
    }
  }
}
