package bci.app.user;

import bci.core.LibraryManager;
import bci.core.User;
import java.util.*;
import pt.tecnico.uilib.menus.Command;

/**
 * 4.2.4. Show all users.
 */
class DoShowUsers extends Command<LibraryManager> {

  DoShowUsers(LibraryManager receiver) {
    super(Label.SHOW_USERS, receiver);
  }

  @Override
  protected final void execute() {
    List<User> sortedUsers = new ArrayList<>(_receiver.getUsers());
    Collections.sort(sortedUsers, Comparator.comparing(User::getName));
    for (User user : sortedUsers){
      _display.popup(user.toString());
    }
  }
}
