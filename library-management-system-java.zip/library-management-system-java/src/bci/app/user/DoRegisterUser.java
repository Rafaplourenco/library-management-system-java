package bci.app.user;

import bci.app.exception.UserRegistrationFailedException;
import bci.core.LibraryManager;
import pt.tecnico.uilib.menus.Command;
import pt.tecnico.uilib.menus.CommandException;

/**
 * 4.2.1. Register new user.
 */
class DoRegisterUser extends Command<LibraryManager> {

  DoRegisterUser(LibraryManager receiver) {
    super(Label.REGISTER_USER, receiver);
    addStringField("name",Prompt.userName());
    addStringField("email",Prompt.userEMail());
  }

  @Override
  protected final void execute() throws CommandException {
    try {
      _display.add(Message.registrationSuccessful(_receiver.registerUser(stringField("name"),stringField("email")).getId()));
    } catch (IllegalArgumentException e) {
      throw new UserRegistrationFailedException(stringField("name"), stringField("email"));
    }
  }
}
