package bci.app.user;

import bci.app.exception.NoSuchUserException;
import bci.core.LibraryManager;
import bci.core.Notification;
import bci.core.User;
import java.util.List;
import pt.tecnico.uilib.menus.Command;
import pt.tecnico.uilib.menus.CommandException;

/**
 * 4.2.3. Show notifications of a specific user.
 */
class DoShowUserNotifications extends Command<LibraryManager> {

  DoShowUserNotifications(LibraryManager receiver) {
    super(Label.SHOW_USER_NOTIFICATIONS, receiver);
    addIntegerField("userId", Prompt.userId());
  }

  @Override
  protected final void execute() throws CommandException {
    int userId = integerField("userId");
    User user = _receiver.getUser(userId);
    if (user == null) {
      throw new NoSuchUserException(userId);
    }
    List<Notification> notifications = user.getNotifications();
    for (Notification n : notifications) {
      _display.addLine(n.toString());
    }
    user.clearNotifications();
  }
}
