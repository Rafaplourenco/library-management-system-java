package bci.app.user;

import bci.app.exception.*;
import bci.core.LibraryManager;
import bci.core.exception.CNoSuchUserException;
import bci.core.exception.UserNotSuspendedException; 
import pt.tecnico.uilib.menus.Command;
import pt.tecnico.uilib.menus.CommandException;

/**
 * 4.2.5. Settle a fine.
 */
class DoPayFine extends Command<LibraryManager> {

  DoPayFine(LibraryManager receiver) {
    super(Label.PAY_FINE, receiver);
    addIntegerField("id", Prompt.userId());
  }

@Override
protected final void execute() throws CommandException {
  try {
    _receiver.payFine(integerField("id"));
  } catch (CNoSuchUserException e) {
    throw new NoSuchUserException(integerField("id"));
  } catch (UserNotSuspendedException e) {
    _display.popup("Saldar multa de utente: Operação inválida: " + e.getMessage());
  }
}
}
