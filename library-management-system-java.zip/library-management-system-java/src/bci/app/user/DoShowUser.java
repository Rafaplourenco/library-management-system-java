package bci.app.user;

import bci.app.exception.NoSuchUserException;
import bci.core.LibraryManager;
import bci.core.User;
import pt.tecnico.uilib.menus.Command;
import pt.tecnico.uilib.menus.CommandException;

/**
 * 4.2.2. Show specific user.
 */
class DoShowUser extends Command<LibraryManager> {

  DoShowUser(LibraryManager receiver) {
    super(Label.SHOW_USER, receiver);
    addIntegerField("id", Prompt.userId());
  }

  @Override
  protected final void execute() throws CommandException {
    User user = _receiver.getUser(integerField("id"));
    if (user == null) {
      throw new NoSuchUserException(integerField("id"));
    }
    _display.add(user);
  }
}
