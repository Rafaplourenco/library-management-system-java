package bci.app.work;

import bci.app.exception.NoSuchWorkException;
import bci.core.LibraryManager;
import bci.core.Work;
import bci.core.exception.CNoSuchWorkException;
import pt.tecnico.uilib.forms.Form;
import pt.tecnico.uilib.menus.Command;
import pt.tecnico.uilib.menus.CommandException;

/**
 * Command to display a work.
 */
class DoDisplayWork extends Command<LibraryManager> {

  DoDisplayWork(LibraryManager receiver) {
    super(Label.SHOW_WORK, receiver);
  }

  @Override
  protected final void execute() throws CommandException {
    pt.tecnico.uilib.forms.Form b = new Form();
    b.addIntegerField("id", Prompt.workId());
    b.parse();
    int id = b.integerField("id");
    try{
      Work work = _receiver.getWork(id);
      _display.addLine(work.toString());
      _display.display();
    } catch (CNoSuchWorkException e) {
      throw new NoSuchWorkException(id);
    }
  }
}
