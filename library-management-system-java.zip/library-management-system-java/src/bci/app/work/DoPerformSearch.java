package bci.app.work;

import bci.core.LibraryManager;
import bci.core.Work;
import pt.tecnico.uilib.forms.Form;
import pt.tecnico.uilib.menus.Command;

/**
* Perform search according to miscellaneous criteria.
*/
class DoPerformSearch extends Command<LibraryManager> {

 DoPerformSearch(LibraryManager receiver) {
   super(Label.PERFORM_SEARCH, receiver);
 }

 /** @see pt.tecnico.po.ui.Command#execute() */
 @Override
 protected final void execute() {
   Form f = new Form();
   f.addStringField("term", Prompt.searchTerm());
   f.parse();
   String term = f.stringField("term");
   for (Work work : _receiver.searchWorks(term)){
     _display.popup(work.toString());
   }
 }
}