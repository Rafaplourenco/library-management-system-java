package bci.app.work;

import bci.app.exception.NoSuchCreatorException;
import bci.core.LibraryManager;
import bci.core.Work;
import java.util.Collections;
import java.util.Comparator;
import pt.tecnico.uilib.menus.Command;
import pt.tecnico.uilib.menus.CommandException;

/**
 * Display all works by a specific creator.
 */
class DoDisplayWorksByCreator extends Command<LibraryManager> {
  DoDisplayWorksByCreator(LibraryManager receiver) {
    super(Label.SHOW_WORKS_BY_CREATOR, receiver);
    addStringField("creator", Prompt.creatorId());
  }

  @Override
  protected final void execute() throws CommandException {
    String creatorName = stringField("creator");
    java.util.List<Work> works = _receiver.getWorksByCreator(creatorName);
    if (works == null) {
      throw new NoSuchCreatorException(creatorName);
    }
    Collections.sort(works, Comparator.comparing(Work::getTitle, String.CASE_INSENSITIVE_ORDER));
    for (Work work : works) {
      _display.popup(work.toString());
    }
  }
}
