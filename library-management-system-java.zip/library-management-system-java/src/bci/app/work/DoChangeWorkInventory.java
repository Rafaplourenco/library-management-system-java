package bci.app.work;

import bci.core.LibraryManager;
import bci.core.exception.CNoSuchWorkException;
import pt.tecnico.uilib.forms.Form;
import pt.tecnico.uilib.menus.Command;
import pt.tecnico.uilib.menus.CommandException;

/**
 * Change the number of exemplars of a work.
 */
class DoChangeWorkInventory extends Command<LibraryManager> {
   DoChangeWorkInventory(LibraryManager receiver) {
     super(Label.CHANGE_WORK_INVENTORY, receiver);
   }

   @Override
   protected final void execute() throws CommandException {
     Form form = new Form();
     form.addIntegerField("workId", Prompt.workId());
     form.addIntegerField("amount", Prompt.amountToUpdate());
     form.parse();
     int workId = form.integerField("workId");
     int amount = form.integerField("amount");
     try {
       boolean success = _receiver.changeWorkInventory(workId, amount);
       if (!success) {
         _display.addLine(Message.notEnoughInventory(workId, amount));
         _display.display();
       }
     } catch (CNoSuchWorkException e) {
       _display.addLine(Message.noSuchWork(workId));
       _display.display();
     }
   }
}
