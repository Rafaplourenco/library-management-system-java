package bci.app.request;

import bci.app.exception.*;
import bci.core.LibraryManager;
import bci.core.exception.*;
import pt.tecnico.uilib.Display;
import pt.tecnico.uilib.forms.Form;
import pt.tecnico.uilib.menus.Command;
import pt.tecnico.uilib.menus.CommandException;

/**
 * 4.4.2. Return a work.
 */
class DoReturnWork extends Command<LibraryManager> {

  DoReturnWork(LibraryManager receiver) {
    super(Label.RETURN_WORK, receiver);
    addIntegerField("userId", "Introduza o número de utente: ");
    addIntegerField("workId", "Introduza o número da obra: ");
  }

  @Override
  protected final void execute() throws CommandException {
    int userId = integerField("userId");
    int workId = integerField("workId");
    try {
      _receiver.returnWork(userId, workId);
    } catch (CNoSuchUserException e) {
      throw new NoSuchUserException(userId);
    } catch (CNoSuchWorkException e) {
      throw new NoSuchWorkException(workId);
    } catch (NoSuchBorrowException e) {
      throw new WorkNotBorrowedByUserException(workId, userId);
    }
    try {
      if (_receiver.getFine(userId) != 0){
        new Display().add(Message.showFine(userId, _receiver.getFine(userId))).display();
        if (Form.confirm(Prompt.finePaymentChoice())){
          _receiver.payFine(userId);
        }
      }
    } catch (CNoSuchUserException e) {
    } catch (UserNotSuspendedException e) {
    }
  }
}
