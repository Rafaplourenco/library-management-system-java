package bci.app.request;

import bci.app.exception.NoSuchUserException;
import bci.app.exception.NoSuchWorkException;
import bci.core.LibraryManager;
import bci.core.User;
import bci.core.Work;
import bci.core.exception.BorrowingRuleFailedException;
import bci.core.exception.CNoSuchUserException;
import bci.core.exception.CNoSuchWorkException;
import pt.tecnico.uilib.forms.Form;
import pt.tecnico.uilib.menus.Command;
import pt.tecnico.uilib.menus.CommandException;

/**
 * 4.4.1. Request work.
 */
class DoRequestWork extends Command<LibraryManager> {

  DoRequestWork(LibraryManager receiver) {
    super(Label.REQUEST_WORK, receiver);
    addIntegerField("userId", "Introduza o número de utente: ");
    addIntegerField("workId", "Introduza o número da obra: ");
  }

  @Override
  protected final void execute() throws CommandException {
    int userId = integerField("userId");
    int workId = integerField("workId");
    User user = _receiver.getUser(userId);
    if (user == null) {
      throw new NoSuchUserException(userId);
    }
    try {
      Work work = _receiver.getWork(workId);
      if (work.getNumberOfCopiesAvailable() <= 0) {
        boolean notify = Form.confirm(Prompt.returnNotificationPreference());
        if (notify) {
          work.addObserver(user);
        }
      } else {
        try {
          int returnDate = _receiver.requestWork(userId, workId);
          _display.addLine(Message.workReturnDay(workId, returnDate));
        } catch (CNoSuchUserException e) {
          throw new NoSuchUserException(userId);
        } catch (CNoSuchWorkException e) {
          throw new NoSuchWorkException(workId);
        } catch (BorrowingRuleFailedException e) {
          throw new bci.app.exception.BorrowingRuleFailedException(userId, workId, e.getRuleNumber()); 
        }
      }
    } catch (CNoSuchWorkException e) {
      throw new NoSuchWorkException(workId);
    }
  }
}
