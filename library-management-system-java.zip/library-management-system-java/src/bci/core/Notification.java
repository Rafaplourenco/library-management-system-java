package bci.core;

import java.io.Serializable;

/**
* Representa uma notificação para um utilizador sobre eventos relacionados com obras.
* As notificações podem ser de dois tipos: DISPONIBILIDADE ou REQUISICAO.
*/
public class Notification implements Serializable {
   @java.io.Serial
   private static final long serialVersionUID = 202501101348L;

   /** Tipos possíveis de notificação */
   public enum Type {
       DISPONIBILIDADE,
       REQUISICAO
   }

   private Type _type;
   private String _workDescription;
   private int _workId;

   /**
    * Constrói uma nova notificação.
    *
    * @param type tipo da notificação (DISPONIBILIDADE ou REQUISICAO)
    * @param workDescription descrição da obra (formato usado para mostrar obras)
    * @param workId identificador da obra
    */
   public Notification(Type type, String workDescription, int workId) {
       _type = type;
       _workDescription = workDescription;
       _workId = workId;
   }

   public Type getType() {
       return _type;
   }

   public String getWorkDescription() {
       return _workDescription;
   }

   public int getWorkId() {
       return _workId;
   }

   @Override
   public String toString() {
       String typeStr = switch (_type) {
           case DISPONIBILIDADE -> "DISPONIBILIDADE";
           case REQUISICAO -> "REQUISICAO";
       };
       return typeStr + ": " + _workDescription;
   }
}

