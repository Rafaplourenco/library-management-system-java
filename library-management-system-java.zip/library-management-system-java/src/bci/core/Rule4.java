package bci.core;

import bci.core.exception.BorrowingRuleFailedException;

/**
 * Rule 4: User cannot have more than N works borrowed (N depends on behavior).
 */
public class Rule4 extends Rule {
    public Rule4() {
        super(4);
    }

    @Override
    public void check(User user, Work work) throws BorrowingRuleFailedException {
        int maxWorks = 3;
        if (user.getBehaviour() == UserBehaviour.CUMPRIDOR) maxWorks = 5;
        else if (user.getBehaviour() == UserBehaviour.FALTOSO) maxWorks = 1;
        if (user.getBorrowedWorksList().size() >= maxWorks) {
            throw new BorrowingRuleFailedException(user.getId(), work.getId(), _ruleNumber);
        }
    }
}