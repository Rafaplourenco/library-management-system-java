package bci.core.exception;

public class CNoSuchUserException  extends Exception{
    public CNoSuchUserException(){
        super();
    }
    public CNoSuchUserException(int id){
        super("O utente " + id + " não existe.");
    }
}
