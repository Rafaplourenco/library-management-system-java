package bci.core.exception;

public class UserNotSuspendedException extends Exception {
  private final int _userId;

  public UserNotSuspendedException(int userId) {
    super("O utente " + userId + " não se encontra suspenso.");
    _userId = userId;
  }

  public int getUserId() {
    return _userId;
  }
}
