package bci.core.exception;

public class NoSuchBorrowException extends Exception{
    public NoSuchBorrowException(){
        super();
    }
}
