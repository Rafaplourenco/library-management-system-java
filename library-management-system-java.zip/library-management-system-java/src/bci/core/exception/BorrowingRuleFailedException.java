package bci.core.exception;

public class BorrowingRuleFailedException extends Exception {
  private final int _userId;
  private final int _workId;
  private final int _ruleNumber;

  public BorrowingRuleFailedException(int idUser, int idWork, int idRule) {
    super("O utente " + idUser + " não pode requisitar a obra " + idWork +
          ". Violação da regra " + idRule + ".");
    this._userId = idUser;
    this._workId = idWork;
    this._ruleNumber = idRule;
  }

  public int getUserId() { return _userId; }
  public int getWorkId() { return _workId; }
  public int getRuleNumber() { return _ruleNumber; }
}
