package bci.core.exception;

public class CNoSuchWorkException extends Exception {
    public CNoSuchWorkException(){
        super();
    }
}
