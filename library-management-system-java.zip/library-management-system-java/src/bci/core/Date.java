package bci.core;
import java.io.Serializable;
public class Date implements Serializable{
  private static final long serialVersionUID = 1L;
    private int _currentDate;
    public Date(){
        _currentDate = 1;
    }
    public int getCurrentDate(){
        return _currentDate;
    }
    public void advanceDate(int nDays){
        _currentDate += nDays;
    }
}