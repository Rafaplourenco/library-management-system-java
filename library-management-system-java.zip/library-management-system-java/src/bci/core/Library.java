package bci.core;


import bci.app.exception.NoSuchUserException;
import bci.app.exception.NoSuchWorkException;
import bci.app.exception.WorkNotBorrowedByUserException;
import bci.core.exception.BorrowingRuleFailedException;
import bci.core.exception.CNoSuchUserException;
import bci.core.exception.CNoSuchWorkException;
import bci.core.exception.NoSuchBorrowException;
import bci.core.exception.UnrecognizedEntryException;
import java.io.*;
import java.util.*;


/**
 * Representa a biblioteca enquanto sistema/aplicação, contendo estado global
 * e operações de gestão de utilizadores, criadores e obras.
 * <p>
 * Esta classe é serializável para permitir persistência.
 */
public class Library implements Serializable {
  /**
   * Identificador de versão da classe para efeitos de serialização.
   */
  @Serial
  public static final long serialVersionUID = 202501101348L;

  // ---Data---//
  /** Data "corrente" do sistema (classe própria que encapsula operações sobre datas). */
  private Date _currentDate;
  //---Id---//
  /** Próximo identificador a atribuir a uma obra. */
  private int _nextWorkId;
  /** Próximo identificador a atribuir a um utilizador. */
  private int _nextUserId;
  /** Indica se o estado da biblioteca foi modificado desde a última persistência. */
  private boolean _modified;
  /** Lista de utilizadores registados. */
  private List<User> _users;
  /** Conjunto de criadores (autores/realizadores) registados. */
  private Set<Creator> _creators;
  /** Lista de obras (livros, DVDs, etc.) registadas. */
  private List<Work> _works;

  /**
   * Constrói uma nova instância de {@code Library} com estado inicial vazio e
   * contadores (IDs) a começar em 1.
   */
  public Library(){
    _currentDate = new Date();
    _users = new ArrayList<>();
    _creators = new HashSet<>();
    _works = new ArrayList<>();
    _nextWorkId = 1;
    _nextUserId = 1;
    _modified = false;
  }

  /**
   * Obtém a data corrente do sistema como inteiro (delegando na classe {@code Date}).
   *
   * @return inteiro representando a data corrente segundo a convenção da classe {@code Date}
   */
  public int getCurrentDate(){
    return _currentDate.getCurrentDate();
  }

  /**
   * Representa um registo de empréstimo de uma obra.
   */
  public static class BorrowRecord implements Serializable {
    @Serial private static final long serialVersionUID = 202520100948L;

    private final Work work;
    private final int borrowDate;
    private final int dueDate;
    private Integer returnDate;

    /**
     * Constrói um novo registo de empréstimo.
     * @param work a obra emprestada
     * @param borrowDate data de empréstimo
     * @param dueDate data de devolução prevista
     */
    BorrowRecord(Work work, int borrowDate, int dueDate) {
      this.work = work;
      this.borrowDate = borrowDate;
      this.dueDate = dueDate;
    }
    public Work getWork() { return work; }
    public int getBorrowDate() { return borrowDate; }
    public int getDueDate() { return dueDate; }
    /**
     * Obtém a data de devolução efetiva.
     * @return data de devolução, ou null se não devolvida
     */
    public Integer getReturnDate() { return returnDate; }

    /**
     * Define a data de devolução efetiva.
     * @param day data de devolução
     */
    public void setReturnDate(int day) { this.returnDate = day; }
  }
  /**
   * Avança a data corrente um determinado número de dias (apenas se positivo).
   *
   * @param nDays número de dias a avançar; valores não positivos são ignorados
   */
    public void advanceDate(int nDays) {
      if (nDays <= 0) return;

      _currentDate.advanceDate(nDays);

      for (User u : _users) {
        boolean hasOverdue = false;

        for (Library.BorrowRecord r : u.getBorrowHistory()) {
          Integer ret = r.getReturnDate();
          if (ret == null && getCurrentDate() > r.getDueDate()) {
            hasOverdue = true;
            break;
          }
        }
        if (hasOverdue || u.getFine() > 0) {
          u.suspend();
        } else {
          u.activate(); 
        }
      }

      _modified = true;
    }

  /**
   * Regista um novo utilizador na biblioteca.
   *
   * @param userName nome do utilizador
   * @param email    endereço de email do utilizador
   * @return o {@link User} criado
   */
  public User registerUser(String userName,String email){
    if (userName == null || userName.trim().isEmpty() || email == null || email.trim().isEmpty()){
      throw new IllegalArgumentException("Invalid user data");
    }
    User u = new User(_nextUserId, userName, email);
    _users.add(u);
    _nextUserId++;
    return u;
  }

  /**
   * Regista um criador. Se já existir um criador com o mesmo nome, devolve o existente.
   *
   * @param name nome do criador
   * @return o {@link Creator} correspondente (existente ou novo)
   */
  public Creator registerCreator(String name){
    for (Creator c : _creators){
      if (c.getName().equals(name)){
        return c;
      }
    }
    Creator c = new Creator(name);
    _creators.add(c);
    return c;
  }

  /**
   * Obtém um utilizador pelo seu identificador.
   *
   * @param id identificador do utilizador
   * @return o {@link User} correspondente, ou {@code null} se não existir
   */
  public User getUser(int id){
    for (User u: _users){
      if (u.getId() == id){
        return u;
      }
    } 
    return null;
  }

  /**
   * Devolve a lista de todos os utilizadores.
   *
   * @return lista mutável de {@link User}
   */
  public List<User> getUsers(){
    return _users;
  }

  /**
   * Obtém uma obra pelo seu identificador.
   *
   * @param id identificador da obra
   * @return a {@link Work} correspondente
   * @throws NoSuchWorkException se não existir obra com o identificador dado
   */
  public Work getWork(int id) throws CNoSuchWorkException{
    for (Work w: _works){
      if (w.getId() == id){
        return w;
      }
    }
    throw new CNoSuchWorkException();
  }

  /**
   * Devolve a lista de todas as obras.
   *
   * @return lista mutável de {@link Work}
   */
  public List<Work> getWorks(){
    return _works;
  }

  /**
   * Obtém todas as obras de um dado criador.
   *
   * @param creatorName nome do criador
   * @return lista de {@link Work} do criador, ou {@code null} se o criador não existir
   */
  public List<Work> getWorksByCreator(String creatorName){
    for (Creator c: _creators){
      if (c.getName().equals(creatorName)){
        return c.getWorks();
      }
    }
    return null;
  }

  /**
   * Pesquisa obras por termo no título ou nome do criador.
   *
   * @param term termo de pesquisa
   * @return lista de {@link Work} que contêm o termo no título ou nome do criador, ordenada por identificador
   */
  public List<Work> searchWorks(String term) {
    List<Work> result = new ArrayList<>();
    String lowerTerm = term.toLowerCase();
    for (Work w : _works) {
      if (w.getTitle().toLowerCase().contains(lowerTerm)) {
        result.add(w);
      } else {
        for (Creator c : w.getCreators()) {
          if (c.getName().toLowerCase().contains(lowerTerm)) {
            result.add(w);
            break;
          }
        }
      }
    }
    result.sort(Comparator.comparing(Work::getId));
    return result;
  }

  /**
   * Requisita uma obra para um utilizador.
   *
   * @param userId identificador do utilizador
   * @param workId identificador da obra
   * @return data de devolução
   * @throws NoSuchUserException se o utilizador não existir
   * @throws NoSuchWorkException se a obra não existir
   * @throws BorrowingRuleFailedException se a requisição violar regras de empréstimo
   */
  public int requestWork(int userId, int workId)
      throws CNoSuchUserException, CNoSuchWorkException, BorrowingRuleFailedException {

    User user = getUser(userId);
    if (user == null)
      throw new CNoSuchUserException(userId);

    Work work = getWork(workId);

    Rule[] rules = { new Rule1(), new Rule2(), new Rule3(), new Rule4(), new Rule5(), new Rule6() };
    for (Rule rule : rules) {
      rule.check(user, work);
    }
    
  int totalCopies = work.getNumberOfCopies();
  int loanPeriod;
  if (user.getBehaviour() == UserBehaviour.FALTOSO) {
    loanPeriod = 2;
  } else if (user.getBehaviour() == UserBehaviour.CUMPRIDOR) {
    if (totalCopies == 1)      loanPeriod = 8;
    else if (totalCopies <= 5) loanPeriod = 15;
    else                       loanPeriod = 30;
  } else { 
    if (totalCopies == 1)      loanPeriod = 3;
    else if (totalCopies <= 5) loanPeriod = 8;
    else                       loanPeriod = 15;
  }

  int returnDate = getCurrentDate() + loanPeriod;
  user.addBorrowedWork(work, getCurrentDate(), returnDate);
  work.setNumberOfCopiesAvailable(work.getNumberOfCopiesAvailable() - 1);
  _modified = true;
  return returnDate;
  }

  /**
   * Devolve uma obra requisitada por um utilizador.
   *
   * @param userId identificador do utilizador
   * @param workId identificador da obra
   * @throws NoSuchUserException se o utilizador não existir
   * @throws NoSuchWorkException se a obra não existir
   * @throws WorkNotBorrowedByUserException se a obra não foi requisitada pelo utilizador
   */
  public void returnWork(int userId, int workId) throws CNoSuchUserException, CNoSuchWorkException, NoSuchBorrowException {
    User user = getUser(userId);
    if (user == null) {
      throw new CNoSuchUserException(userId);
    }
    Work work = getWork(workId);
    if (!user.hasBorrowed(work)) {
      throw new NoSuchBorrowException();
    }
    int dueDate = user.getDueDateOfBorrow(work);
    if (getCurrentDate() > dueDate) {
      int daysLate = getCurrentDate() - dueDate;
      user.addFine(daysLate * 5);
    }
    user.removeBorrowedWork(work, getCurrentDate());
    user.updateBehaviour();
    int prevAvail = work.getNumberOfCopiesAvailable();
    work.setNumberOfCopiesAvailable(prevAvail + 1);
    if (prevAvail == 0) {
      Notification n = new Notification(Notification.Type.DISPONIBILIDADE, work.toString(), workId);
      work.notifyObservers(n);
    }
_modified = true;

}

/**
* Empréstimo de uma obra para um utilizador (delegado para requestWork).
* @param library a biblioteca (não utilizado)
* @param userId identificador do utilizador
* @param workId identificador da obra
* @return data de devolução
* @throws CNoSuchUserException se o utilizador não existir
* @throws CNoSuchWorkException se a obra não existir
* @throws BorrowingRuleFailedException se violar regras
*/
public int borrow(Library library, int userId, int workId)
      throws CNoSuchUserException, CNoSuchWorkException, BorrowingRuleFailedException {
    return this.requestWork(userId, workId);
  }
  /**
   * Altera o número de exemplares disponíveis de uma obra.
   *
   * @param workId identificador da obra
   * @param amount quantidade a adicionar (pode ser positiva ou negativa)
   * @return true se a operação foi bem-sucedida, false se inválida
   * @throws NoSuchWorkException se a obra não existir
   */
  public boolean changeWorkInventory(int workId, int amount) throws CNoSuchWorkException {
    Work work = getWork(workId);
    int newAvailable = work.getNumberOfCopiesAvailable() + amount;
    if (newAvailable < 0) {
      return false;
    } else if (newAvailable == 0) {
      _works.remove(work);
      for (Creator c : work.getCreators()) {
        c.getWorks().remove(work);
      }
      _modified = true;
      return true;
    } else {
      work.setNumberOfCopiesAvailable(newAvailable);

      work.setNumberOfCopies(work.getNumberOfCopies() + amount);
      _modified = true;
      return true;
    }
  }

  /**
   * Obtém a multa de um utilizador.
   * @param userId identificador do utilizador
   * @return valor da multa
   * @throws CNoSuchUserException se o utilizador não existir
   */
  public int getFine(int userId) throws CNoSuchUserException {
    User user = getUser(userId);
    if (user == null) {
      throw new CNoSuchUserException(userId);
    }
    return user.getFine();
  }

  /**
   * Regista um novo livro na biblioteca.
   *
   * @param isbn            ISBN do livro
   * @param creators        lista de criadores/autores do livro
   * @param title           título da obra
   * @param price           preço base da obra
   * @param numberOfCopies  número de cópias disponíveis
   * @param category        categoria/assunto do livro
   */
  public void registerBook(String isbn, List<Creator> creators,String title, int price, int numberOfCopies, Category category){
    Book b = new Book(isbn, _nextWorkId, title, price, numberOfCopies, category);
    b.SetCreators(creators);
    for (Creator c : creators){
      c.addWork(b);
    }
    _works.add(b);
    _nextWorkId ++;
  }

  /**
   * Regista um novo DVD na biblioteca.
   *
   * @param igac            número/registo IGAC do DVD
   * @param creator         criador/realizador principal
   * @param title           título da obra
   * @param price           preço base da obra
   * @param numberOfCopies  número de cópias disponíveis
   * @param category        categoria/assunto do DVD
   */
  public void registerDvd(String igac, Creator creator, String title, int price, int numberOfCopies, Category category){
    Dvd d = new Dvd(igac, _nextWorkId, title, price, numberOfCopies, category);
    List<Creator> creators = new ArrayList<>();
    creators.add(creator);
    d.SetCreators(creators);
    _works.add(d);
    creator.addWork(d);
    _nextWorkId++;
  }

  /**
   * Lê um ficheiro de texto no arranque e popula o estado desta biblioteca com as
   * entidades nele descritas.
   *
   * @param filename nome do ficheiro de entrada a processar
   * @throws UnrecognizedEntryException se alguma entrada estiver mal formatada
   * @throws IOException                se ocorrer um erro de E/S durante o processamento
   */
  void importFile(String filename) throws UnrecognizedEntryException, IOException /* FIXME maybe other exceptions */  {
    Parser parser = new Parser(this);
    parser.parseFile(filename);
  }
}
