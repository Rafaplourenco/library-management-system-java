package bci.core;

public class Book extends Work{
    private String _isbn;
    public Book(String isbn, int id, String title, int price, int numberOfCopies, Category category){
        super (id, title, price, numberOfCopies, category);
        _isbn = isbn;
    }
    @Override
    public String toString(){
        String details = getId() + " - " + getNumberOfCopiesAvailable() + " de " + getNumberOfCopies() + " - Livro - " + getTitle() + " - " + getPrice() + " - " + getCategory() + " - ";
        for (int c = 0; c != getCreators().size(); c++){
            details += getCreators().get(c).getName();
            if (c != getCreators().size() - 1){
                details += "; ";
            }
        }
        return details + " - " + _isbn;
    }
} 