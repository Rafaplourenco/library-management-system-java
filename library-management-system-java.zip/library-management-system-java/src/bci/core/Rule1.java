package bci.core;

import bci.core.exception.BorrowingRuleFailedException;

/**
 * Rule 1: User cannot borrow the same work twice.
 */
public class Rule1 extends Rule {
    public Rule1() {
        super(1);
    }

    @Override
    public void check(User user, Work work) throws BorrowingRuleFailedException {
        if (user.hasBorrowed(work)) {
            throw new BorrowingRuleFailedException(user.getId(), work.getId(), _ruleNumber);
        }
    }
}