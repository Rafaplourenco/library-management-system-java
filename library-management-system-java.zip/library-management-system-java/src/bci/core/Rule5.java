package bci.core;

import bci.core.exception.BorrowingRuleFailedException;

/**
 * Rule 5: Work category cannot be REFERENCE.
 */
public class Rule5 extends Rule {
    public Rule5() {
        super(5);
    }

    @Override
    public void check(User user, Work work) throws BorrowingRuleFailedException {
        if (work.getCategoryEnum() == Category.REFERENCE) {
            throw new BorrowingRuleFailedException(user.getId(), work.getId(), _ruleNumber);
        }
    }
}