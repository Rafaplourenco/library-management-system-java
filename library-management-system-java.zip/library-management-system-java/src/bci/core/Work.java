package bci.core;
import java.io.Serializable;
import java.util.*;


public abstract class Work implements Serializable{
  @java.io.Serial
  private static final long serialVersionUID = 202501101348L;
    private int _id;
    private int _price;
    private int _numberOfCopies;
    private int _numberOfCopiesAvailable;
    private String _title;
    private Category _category;
    private List<Creator> _creators;
    private List<WorkObserver> _observers;

    public Work(int id, String title, int price, int numberOfCopies, Category category){
        _id = id;
        _title = title;
        _price = price;
        _numberOfCopies = numberOfCopies;
        _numberOfCopiesAvailable = _numberOfCopies;
        _category = category;
        _creators = new ArrayList<>();
        _observers = new ArrayList<>();
    }
    public String getDescription(){
        return toString();
    }
    public int getId(){
        return _id;
    }
    public int getPrice(){
        return _price;
    }
    public int getNumberOfCopies(){
        return _numberOfCopies;
    }
    public int getNumberOfCopiesAvailable(){
        return _numberOfCopiesAvailable;
    }
    public void setNumberOfCopiesAvailable(int numberOfCopiesAvailable){
        _numberOfCopiesAvailable = numberOfCopiesAvailable;
    }
    public void setNumberOfCopies(int numberOfCopies){
        _numberOfCopies = numberOfCopies;
    }
    public String getTitle(){
        return _title;
    }
    public Category getCategoryEnum(){
        return _category;
    }
    public String getCategory(){
        if (_category == Category.REFERENCE){
            return "Referência";
        }
        if (_category == Category.FICTION){
            return "Ficção";
        }
        return "Técnica e Científica";
    }
    public List<Creator>getCreators(){
        return _creators;
    }
    public void SetCreators(List<Creator> creators){
        _creators = creators;
    }
    public void addObserver(WorkObserver observer){
        _observers.add(observer);
    }
    public void removeObserver(WorkObserver observer){
        _observers.remove(observer);
    }
    public void notifyObservers(Notification notification){
        for (WorkObserver observer : _observers){
            observer.update(notification);
        }
    }
    public abstract String toString();
}