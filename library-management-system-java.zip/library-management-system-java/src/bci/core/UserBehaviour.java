package bci.core;

public enum UserBehaviour{
    NORMAL,
    CUMPRIDOR,
    FALTOSO
}