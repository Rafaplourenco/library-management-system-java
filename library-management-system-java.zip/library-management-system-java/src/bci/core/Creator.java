package bci.core;
import java.io.Serializable;
import java.util.*;

public class Creator implements Serializable{
  @java.io.Serial
  private static final long serialVersionUID = 202501101348L;
    private String _name;
    private List<Work> _works;
    public Creator(String name) {
        _name = name;
        _works = new ArrayList<>();
    }
    public String getName(){
        return _name;
    }
    public void add(Work work){
        _works.add(work);
    }
    public List<Work> getWorks(){
        return _works;
    }
    public void addWork(Work work){
        _works.add(work);
    }
    @Override
    public String toString(){
        return _name;
    }
}