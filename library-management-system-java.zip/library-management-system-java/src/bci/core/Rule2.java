package bci.core;

import bci.core.exception.BorrowingRuleFailedException;

/**
 * Rule 2: User must be active.
 */
public class Rule2 extends Rule {
    public Rule2() {
        super(2);
    }

    @Override
    public void check(User user, Work work) throws BorrowingRuleFailedException {
        if (!user.isActive()) {
            throw new BorrowingRuleFailedException(user.getId(), work.getId(), _ruleNumber);
        }
    }
}