package bci.core;

import bci.core.exception.BorrowingRuleFailedException;

/**
 * Rule 3: Work must have at least one available copy.
 */
public class Rule3 extends Rule {
    public Rule3() {
        super(3);
    }

    @Override
    public void check(User user, Work work) throws BorrowingRuleFailedException {
        if (work.getNumberOfCopiesAvailable() <= 0) {
            throw new BorrowingRuleFailedException(user.getId(), work.getId(), _ruleNumber);
        }
    }
}