package bci.core;

import bci.core.exception.BorrowingRuleFailedException;

/**
 * Rule 6: User cannot borrow works with price > 25 (except CUMPRIDOR users).
 */
public class Rule6 extends Rule {
    public Rule6() {
        super(6);
    }

    @Override
    public void check(User user, Work work) throws BorrowingRuleFailedException {
        if (work.getPrice() > 25 && user.getBehaviour() != UserBehaviour.CUMPRIDOR) {
            throw new BorrowingRuleFailedException(user.getId(), work.getId(), _ruleNumber);
        }
    }
}