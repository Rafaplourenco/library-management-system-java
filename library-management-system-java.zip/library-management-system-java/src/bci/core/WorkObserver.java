package bci.core;

/**
 * Observer interface for work availability notifications.
 */
public interface WorkObserver {
    void update(Notification notification);
}