package bci.core;

import bci.core.exception.*;
import java.io.*;
import java.util.*;



// FIXME import classes

/**
 * Classe fachada. Representa o gestor desta aplicação. Gere a biblioteca atual
 * e funciona como interface entre o núcleo e as camadas de interação com o utilizador.
 */
public class LibraryManager {


  /** O objeto que faz todo o trabalho real. */
  /* A biblioteca atual */
  private Library _library;
  private String _filename;
  private boolean _changed = false;

  /**
   * Guarda o estado serializado da aplicação no ficheiro associado à biblioteca atual.
   *
   * @throws FileNotFoundException se por alguma razão o ficheiro não puder ser criado ou aberto.
   * @throws MissingFileAssociationException se a biblioteca atual não tiver um ficheiro.
   * @throws IOException se houver erro ao serializar o estado da rede para o disco.
   **/
  public void save() throws MissingFileAssociationException, FileNotFoundException, IOException {
    if (_filename == null){
      throw new MissingFileAssociationException();
    }
    try (ObjectOutputStream obj = new ObjectOutputStream(new FileOutputStream(_filename))){
      obj.writeObject(_library);
      _changed = false;
    }
  }
  /**
   * Constrói uma nova instância de {@code LibraryManager} com uma biblioteca vazia.
   */
  public LibraryManager(){
    _library = new Library();
    _filename = null;
    _changed = false;
  }

  /**
   * Guarda o estado serializado da aplicação no ficheiro especificado. A biblioteca atual fica
   * associada a este ficheiro.
   *
   * @param filename o nome do ficheiro.
   * @throws FileNotFoundException se por alguma razão o ficheiro não puder ser criado ou aberto.
   * @throws MissingFileAssociationException se a biblioteca atual não tiver um ficheiro.
   * @throws IOException se houver erro ao serializar o estado da rede para o disco.
   **/
  public void saveAs(String filename) throws FileNotFoundException, MissingFileAssociationException, IOException {
    _filename = filename;
    save();
  }

  /**
   * Obtém um utilizador pelo seu identificador.
   * @param id identificador do utilizador
   * @return o utilizador correspondente
   */
  public User getUser(int id){
    return (_library.getUser(id));
  }

  /**
   * Obtém a coleção de todos os utilizadores.
   * @return coleção de utilizadores
   */
  public Collection<User> getUsers(){
    return _library.getUsers();
  }

  /**
   * Avança a data atual um determinado número de dias.
   * @param nDays número de dias a avançar
   */
  public void advanceDate(int nDays){
    _library.advanceDate(nDays);
    _changed = true;
  }

  /**
   * Obtém a data atual.
   * @return data atual
   */
  public int getCurrentDate(){
    return _library.getCurrentDate();
  }

  /**
   * Regista um novo utilizador.
   * @param name nome do utilizador
   * @param email email do utilizador
   * @return o utilizador registado
   */
  public User registerUser(String name,String email){
    User user = _library.registerUser(name,email);
    _changed = true;
    return user;
  }

  /**
   * Obtém uma obra pelo seu identificador.
   * @param id identificador da obra
   * @return a obra correspondente
   * @throws CNoSuchWorkException se a obra não existir
   */
  public Work getWork(int id) throws CNoSuchWorkException{
    return _library.getWork(id);
  }

  /**
   * Obtém a lista de todas as obras.
   * @return lista de obras
   */
  public List<Work> getWorks(){
    return _library.getWorks();
  }

  /**
   * Obtém as obras de um criador específico.
   * @param creatorName nome do criador
   * @return lista de obras do criador
   */
  public List<Work> getWorksByCreator(String creatorName){
    return _library.getWorksByCreator(creatorName);
  }

  /**
   * Pesquisa obras por termo.
   * @param term termo de pesquisa
   * @return lista de obras que correspondem ao termo
   */
  public List<Work> searchWorks(String term){
    return _library.searchWorks(term);
  }

  /**
   * Requisita uma obra para um utilizador.
   * @param userId identificador do utilizador
   * @param workId identificador da obra
   * @return data de devolução
   * @throws CNoSuchUserException se o utilizador não existir
   * @throws CNoSuchWorkException se a obra não existir
   * @throws BorrowingRuleFailedException se violar regras de empréstimo
   */
  public int requestWork(int userId, int workId) throws CNoSuchUserException, CNoSuchWorkException, bci.core.exception.BorrowingRuleFailedException {
    return _library.requestWork(userId, workId);
  }

  /**
   * Devolve uma obra requisitada por um utilizador.
   * @param userId identificador do utilizador
   * @param workId identificador da obra
   * @throws CNoSuchUserException se o utilizador não existir
   * @throws CNoSuchWorkException se a obra não existir
   * @throws NoSuchBorrowException se a obra não foi emprestada pelo utilizador
   */
  public void returnWork(int userId, int workId) throws CNoSuchUserException, CNoSuchWorkException, NoSuchBorrowException {
    _library.returnWork(userId, workId);
  }

  /**
   * Altera o inventário de uma obra.
   * @param workId identificador da obra
   * @param amount quantidade a alterar
   * @return true se bem-sucedido
   * @throws CNoSuchWorkException se a obra não existir
   */
  public boolean changeWorkInventory(int workId, int amount) throws CNoSuchWorkException {
    return _library.changeWorkInventory(workId, amount);
  }

  /**
   * Obtém a multa de um utilizador.
   * @param userId identificador do utilizador
   * @return valor da multa
   * @throws CNoSuchUserException se o utilizador não existir
   */
  public int getFine(int userId) throws CNoSuchUserException {
    return _library.getFine(userId);
  }
  /**
   * Carrega o estado previamente serializado da aplicação e define-o como a biblioteca atual.
   *
   * @param filename nome do ficheiro contendo o estado serializado da aplicação
   *        a carregar.
   * @throws UnavailableFileException se o ficheiro especificado não existir ou houver
   *         erro ao processar este ficheiro.
   **/
  public void load(String filename) throws UnavailableFileException {
    try (ObjectInputStream obj = new ObjectInputStream(new FileInputStream(filename))){
      _library = (Library) obj.readObject();
      _filename = filename;
      _changed = false;
    } catch (IOException | ClassNotFoundException e){
      throw new UnavailableFileException(filename);
    }
  }

  /**
   * Permite pagar a multa de um utilizador.
   * @param userId identificador do utilizador
   * @throws CNoSuchUserException se o utilizador não existir
   * @throws UserNotSuspendedException se o utilizador não estiver suspenso
   */
  public void payFine(int userId) throws CNoSuchUserException, UserNotSuspendedException {
    User user = getUser(userId);
    if (user == null) throw new CNoSuchUserException(userId);

    if (user.isActive())
      throw new UserNotSuspendedException(userId);
    user.payFine();

    boolean hasOverdues = false;
    for (Library.BorrowRecord r : user.getBorrowHistory()) {
      Integer ret = r.getReturnDate();
      if (ret == null && getCurrentDate() > r.getDueDate()) {
        hasOverdues = true;
        break;
      }
    }
    if (hasOverdues) {
      user.suspend(); 
    } else {
      user.activate();
    }

    _changed = true;
  }

  /**
   * Lê ficheiro de entrada de texto e inicializa a biblioteca atual (que deve estar vazia)
   * com as entidades de domínio representadas no ficheiro de importação.
   *
   * @param datafile nome do ficheiro de entrada de texto
   * @throws ImportFileException se algum erro acontecer durante o processamento do
   * ficheiro de importação.
   **/
  public void importFile(String datafile) throws ImportFileException {
    try {
      if (datafile != null && !datafile.isEmpty())
        _library.importFile(datafile);
    } catch (IOException | UnrecognizedEntryException /* FIXME maybe other exceptions */ e) {
      throw new ImportFileException(datafile, e);
    }
  }

  /**
   * Verifica se há alterações não guardadas.
   * @return true se houver alterações não guardadas
   */
  public boolean hasUnsavedChanges() {
    return _changed;
  }
}
