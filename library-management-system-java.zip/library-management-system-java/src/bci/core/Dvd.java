package bci.core;
public class Dvd extends Work{
    private String _igac;
    public Dvd(String igac, int id, String title, int price, int numberOfCopies, Category category){
        super (id, title, price, numberOfCopies, category);
        _igac = igac;
    }
    public String toString(){
        return getId() + " - " + getNumberOfCopiesAvailable() + " de " + getNumberOfCopies() + " - DVD - " + getTitle() + " - " + getPrice() + " - " + getCategory() + " - " + getCreators().get(0).getName() + " - " + _igac;
    }
}