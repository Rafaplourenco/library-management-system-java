package bci.core;
import bci.core.Library.BorrowRecord;
import bci.core.exception.NoSuchBorrowException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class User implements WorkObserver, Serializable{
  @java.io.Serial
  private static final long serialVersionUID = 202501101348L;

      private int _id;
      private boolean _isActive;
      private String _name;
      private String _email;
      private int _fine;
      private UserBehaviour _behaviour;
      private List<Work> _borrowedWorks;
      private List<Notification> _notifications;
      private List<Library.BorrowRecord> _borrowHistory;

    
    public User(int id, String name, String email){
        _id = id;
        _name = name;
        _email = email;
        _isActive = true;
        _fine = 0;
        _behaviour = UserBehaviour.NORMAL;
        _borrowedWorks = new ArrayList<>();
        _notifications = new ArrayList<>();
        _borrowHistory = new ArrayList<>();
    }
    public int getId(){
        return _id;
    }
    public boolean isActive(){
        return _isActive;
    }
    public String getName(){
        return _name;
    }
    public String getEmail(){
        return _email;
    }
    public int getFine(){
        return _fine;
    }
    public void suspend() {
        _isActive = false;
    }
    public void activate() { 
        _isActive = true; 
    }

    public int getDueDateOfBorrow(Work work) throws NoSuchBorrowException {
        for (int i = _borrowHistory.size() - 1; i >= 0; i--) {
            BorrowRecord r = _borrowHistory.get(i);
            if (r.getWork() == work && r.getReturnDate() == null) {
                return r.getDueDate();
            }
        }
        throw new NoSuchBorrowException();
    }

    public boolean hasBorrowed(Work work) {
        return _borrowedWorks.contains(work);
    }

    public void addBorrowedWork(Work work, int borrowDate, int dueDate) {
        _borrowedWorks.add(work);
        _borrowHistory.add(new BorrowRecord(work, borrowDate, dueDate));
    }

    
    public void removeBorrowedWork(Work work, int returnDate) {
        _borrowedWorks.remove(work);
        for (int i = _borrowHistory.size() - 1; i >= 0; i--) {
            BorrowRecord record = _borrowHistory.get(i);
            if (record.getWork() == work && record.getReturnDate() == null) {
                record.setReturnDate(returnDate); 
                break;
            }
        }
    }

    public void update(Notification notification) {
        _notifications.add(notification);
    }
    public List<Notification> getNotifications() {
        return new ArrayList<>(_notifications);
    }
    public void clearNotifications() {
        _notifications.clear();
    }
    public UserBehaviour getBehaviour() {
        return _behaviour;
    }
    public List<Work> getBorrowedWorksList() {
        return new ArrayList<>(_borrowedWorks);
    }

    public List<Library.BorrowRecord> getBorrowHistory() {
        return new ArrayList<>(_borrowHistory);
    }

    public void payFine() {
        if (_fine > 0) {
            _fine = 0;
        }
    }

    public void addFine(int amount) {
        _fine += amount;
    }
    

    public void updateBehaviour() {
    if (_borrowHistory.isEmpty()) {
        _behaviour = UserBehaviour.NORMAL;
        return;
    }

    java.util.function.Predicate<Library.BorrowRecord> isClosed =
        r -> r.getReturnDate() != null;
    java.util.function.Predicate<Library.BorrowRecord> onTime =
        r -> isClosed.test(r) && r.getReturnDate() <= r.getDueDate();
    java.util.function.Predicate<Library.BorrowRecord> late =
        r -> isClosed.test(r) && r.getReturnDate() > r.getDueDate();

    final int n = _borrowHistory.size();

    if (n >= 5) {
        boolean last5OnTime = true;
        for (int i = n - 5; i < n; i++) {
        if (!onTime.test(_borrowHistory.get(i))) { last5OnTime = false; break; }
        }
        if (last5OnTime) { _behaviour = UserBehaviour.CUMPRIDOR; return; }
    }

    if (_behaviour == UserBehaviour.FALTOSO) {
        int streak = 0;
        for (int i = n - 1; i >= 0; i--) {
        Library.BorrowRecord r = _borrowHistory.get(i);
        if (!isClosed.test(r)) break;       
        if (onTime.test(r)) streak++;       
        else break;                         
        if (streak >= 3) break;
        }
        if (streak < 3) {
        return; 
        }
    }

    if (n >= 3) {
        boolean last3Late = true;
        for (int i = n - 3; i < n; i++) {
        if (!late.test(_borrowHistory.get(i))) { last3Late = false; break; }
        }
        if (last3Late) { _behaviour = UserBehaviour.FALTOSO; return; }
    }

    _behaviour = UserBehaviour.NORMAL;
    }




    public String toString(){
        if (_isActive){
            return _id + " - " + _name + " - " + _email + " - " + _behaviour + " - ACTIVO";
        }
        else{
            return _id + " - " + _name + " - " + _email + " - " + _behaviour + " - SUSPENSO - EUR " + _fine;
        }
    }
}