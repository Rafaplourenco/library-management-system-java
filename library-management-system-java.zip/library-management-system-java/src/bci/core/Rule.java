package bci.core;

import bci.core.exception.BorrowingRuleFailedException;

/**
 * Abstract class for borrowing rules.
 * Each rule checks a specific condition for borrowing a work.
 */
public abstract class Rule {
    protected final int _ruleNumber;

    public Rule(int ruleNumber) {
        _ruleNumber = ruleNumber;
    }

    /**
     * Checks if the rule is satisfied for the given user and work.
     * @param user the user requesting the work
     * @param work the work being requested
     * @throws BorrowingRuleFailedException if the rule is violated
     */
    public abstract void check(User user, Work work) throws BorrowingRuleFailedException;

    public int getRuleNumber() {
        return _ruleNumber;
    }
}